const x="#00ff8c",R="#0A1128",$="https://llrzeexnzgknpwcxdxpm.supabase.co/functions/v1/ai-proxy",C="plug-secret-2025-nexus",E="sb_publishable_5a1gq2zrQY1dKY_Br5oA-Q_3JdRGbtj";function P(){var r,i;const l=['div[role="textbox"][aria-label="Message Body"]','div[role="textbox"][aria-label="גוף ההודעה"]','div[role="textbox"][g_editable="true"]','div.editable[contenteditable="true"]','div[role="textbox"][contenteditable="true"]'],e=document.activeElement;if(e&&((r=e.getAttribute)==null?void 0:r.call(e,"contenteditable"))==="true"&&((i=e.getAttribute)==null?void 0:i.call(e,"role"))==="textbox")return e;for(const a of l){const o=document.querySelector(a);if(o)return o}return null}chrome.runtime.onMessage.addListener((l,e,r)=>{var o;if(l.type!=="INSERT_CHAT_TEXT")return!1;const i=(o=l.payload)==null?void 0:o.text;if(!i)return r({ok:!1}),!0;const a=P();return a?(a.focus(),a.innerHTML=i.replace(/\n/g,"<br>"),a.dispatchEvent(new Event("input",{bubbles:!0})),console.log("[PLUG Gmail] Inserted text into compose editor"),r({ok:!0})):(console.warn("[PLUG Gmail] No compose editor found"),r({ok:!1,error:"no Gmail compose editor found"})),!0});let T=!1;function S(){T||(T=!0,document.addEventListener("mouseup",()=>{var L,h,w,s,b;(L=document.getElementById("plug-rewrite-selection-btn"))==null||L.remove();const l=window.getSelection();if(!l||l.isCollapsed||!l.toString().trim())return;const e=l.anchorNode,r=((w=(h=e==null?void 0:e.parentElement)==null?void 0:h.closest)==null?void 0:w.call(h,'div[role="textbox"][contenteditable="true"], div[g_editable="true"], div.editable[contenteditable="true"]'))||(((b=(s=e==null?void 0:e.parentElement)==null?void 0:s.getAttribute)==null?void 0:b.call(s,"contenteditable"))==="true"?e.parentElement:null);if(!r)return;const i=l.toString().trim();if(i.length<3)return;const a=/[\u0590-\u05FF]/.test(i),o=a?"Respond in Hebrew.":"Respond in English.",d=document.createElement("div");d.id="plug-rewrite-selection-btn",d.style.cssText=`
      position: fixed;
      top: 12px;
      right: 12px;
      z-index: 2147483647;
      display: inline-flex; align-items: center; gap: 3px;
      padding: 4px 6px; border-radius: 10px;
      background: ${R}; border: 1.5px solid ${x}40;
      box-shadow: 0 4px 20px rgba(0,0,0,0.6);
      font-family: system-ui, sans-serif;
    `;const t=[{label:a?"✨ שפר":"✨ Improve",system:`Improve the clarity, flow, and impact of this email text. ${o} Return ONLY the improved text.`},{label:a?"💼 מקצועי":"💼 Professional",system:`Rewrite this email text in a formal, professional tone. ${o} Return ONLY the rewritten text.`},{label:a?"✂️ קצר":"✂️ Shorten",system:`Make this email text shorter and more concise while keeping the key point. ${o} Return ONLY the shortened text.`}],p=i,u=r,g=async(c,k)=>{var n,f;console.log("[PLUG Gmail] Rewrite clicked, action:",c.textContent,"text:",p),t.forEach((G,m)=>{const y=d.children[m];y&&(y.disabled=!0,y.style.opacity="0.5")}),c.textContent="⏳...",c.style.opacity="1";try{const m=await(await fetch($,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${E}`,apikey:E,"X-Plug-Key":C},body:JSON.stringify({system:k,prompt:`Text:
"${p}"`,maxTokens:300})})).json(),y=(typeof(m==null?void 0:m.result)=="string"?m.result:((f=(n=m==null?void 0:m.result)==null?void 0:n.toString)==null?void 0:f.call(n))||"").trim();y&&y!==p&&(u.innerHTML=u.innerHTML.replace(p,y),u.dispatchEvent(new Event("input",{bubbles:!0})),console.log("[PLUG Gmail] Rewrite applied successfully"))}catch(G){console.error("[PLUG Gmail] Rewrite error:",G),c.textContent="❌"}d.remove()};t.forEach(({label:c,system:k})=>{const n=document.createElement("button");n.textContent=c,n.style.cssText=`
        padding: 4px 10px; border-radius: 7px; border: 1px solid ${x}40;
        background: transparent; color: ${x}; cursor: pointer;
        font-size: 11px; font-weight: 600; white-space: nowrap;
        transition: background 0.15s;
      `,n.addEventListener("mouseenter",()=>{n.style.background=`${x}15`}),n.addEventListener("mouseleave",()=>{n.style.background="transparent"}),n.addEventListener("mousedown",f=>{f.preventDefault(),f.stopPropagation()}),n.addEventListener("click",f=>{f.preventDefault(),f.stopPropagation(),g(n,k)}),d.appendChild(n)}),document.body.appendChild(d);const v=c=>{d.contains(c.target)||(d.remove(),document.removeEventListener("mousedown",v))};setTimeout(()=>document.addEventListener("mousedown",v),100)}))}(function(){const e=document.createElement("div");e.id="plug-rewrite-bar",e.style.cssText=`
    position: fixed;
    bottom: 80px;
    right: 16px;
    z-index: 2147483647;
    display: flex;
    align-items: center; gap: 4px;
    padding: 5px 10px;
    border-radius: 12px; background: ${R};
    border: 1.5px solid ${x}50;
    box-shadow: 0 4px 24px rgba(0,0,0,0.5);
    font-family: 'Segoe UI', system-ui, sans-serif;
    opacity: 0; pointer-events: none;
    transition: opacity 0.3s;
  `;const r=document.createElement("span");r.textContent="PLUG",r.style.cssText=`color: ${x}; font-size: 9px; font-weight: 800; letter-spacing: 0.5px; margin-inline-end: 4px; opacity: 0.6;`,e.appendChild(r);const i=/[\u0590-\u05FF]/.test(document.title);[{lbl:i?"✨ שפר":"✨ Improve",system:"Improve the clarity, flow, and impact of this email. Return ONLY the improved text."},{lbl:i?"💼 מקצועי":"💼 Pro",system:"Rewrite this email in a formal, professional tone. Return ONLY the rewritten text."},{lbl:i?"✂️ קצר":"✂️ Short",system:"Make this email shorter and more concise while keeping the key point. Return ONLY the shortened text."}].forEach(({lbl:o,system:d})=>{const t=document.createElement("button");t.textContent=o,t.style.cssText=`
      padding: 4px 10px; border-radius: 7px; border: 1px solid ${x}40;
      background: transparent; color: ${x}; cursor: pointer;
      font-size: 11px; font-weight: 600; white-space: nowrap;
      transition: background 0.15s, opacity 0.15s;
    `,t.addEventListener("mouseenter",()=>{t.style.background=`${x}20`}),t.addEventListener("mouseleave",()=>{t.style.background="transparent"}),t.addEventListener("mousedown",p=>{p.preventDefault()}),t.addEventListener("click",async p=>{var w;p.preventDefault(),p.stopPropagation();const u=P();if(!u){console.warn("[PLUG Gmail] No editor found");return}const g=(w=u.innerText)==null?void 0:w.trim();if(!g||g.length<2){console.warn("[PLUG Gmail] No text in editor");return}const v=t.textContent;e.querySelectorAll("button").forEach(s=>{s.disabled=!0,s.style.opacity="0.4"}),t.textContent="⏳...",t.style.opacity="1";const h=/[\u0590-\u05FF]/.test(g)?"Respond in Hebrew.":"Respond in English.";try{const b=await(await fetch($,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${E}`,apikey:E,"X-Plug-Key":C},body:JSON.stringify({system:`${d} ${h}`,prompt:`Text:
"${g}"`,maxTokens:400})})).json();console.log("[PLUG Gmail] Rewrite result:",b);const c=(typeof(b==null?void 0:b.result)=="string"?b.result:"").trim();c&&(u.focus(),u.innerHTML=c.replace(/\n/g,"<br>"),u.dispatchEvent(new Event("input",{bubbles:!0})))}catch(s){console.error("[PLUG Gmail] Rewrite error:",s)}e.querySelectorAll("button").forEach(s=>{s.disabled=!1,s.style.opacity="1"}),t.textContent=v}),e.appendChild(t)}),document.body.appendChild(e),setInterval(()=>{const o=!!P();e.style.opacity=o?"1":"0",e.style.pointerEvents=o?"auto":"none"},1500)})();S();console.log("[PLUG] Gmail content script loaded");
//# sourceMappingURL=gmail.js.map
