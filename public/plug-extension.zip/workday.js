const i="#00FF9D",U="#0A0F1E";const k="https://llrzeexnzgknpwcxdxpm.supabase.co/functions/v1/ai-proxy",b="sb_publishable_5a1gq2zrQY1dKY_Br5oA-Q_3JdRGbtj",B="plug-secret-2025-nexus";function S(){const t=window.location.hostname,e=t.split(".")[0],n=window.location.pathname.split("/").filter(Boolean);if(n.length===0)return null;const o=n[0],a=`https://${t}/wday/cxs/${e}/${o}/jobs`;return{tenant:e,tenantPath:o,apiUrl:a,hostname:t}}async function _(t,e=0,n=20){const o=await fetch(t,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({limit:n,offset:e,searchText:"",appliedFacets:{}})});if(!o.ok)throw new Error(`Workday API ${o.status}`);return o.json()}function A(t,e){const{hostname:n,tenant:o,tenantPath:a}=e,s=`https://${n}/${a}${t.externalPath}`,r=t.reqId||t.externalPath.split("/").pop()||t.externalPath.replace(/\//g,"-"),h=o.charAt(0).toUpperCase()+o.slice(1);return{id:`workday-${o}-${r}`,title:t.title,company:h,location:t.locationsText||"",link:s,source:"workday",extractedAt:Date.now()}}let y;async function G(){return new Promise(t=>chrome.storage.local.get("profile",e=>t(e.profile??null)))}async function N(t,e){var s;const n=`אתה מנתח התאמה בין מועמד למשרה עבור פלטפורמת PLUG.

פרופיל המועמד:
- שם: ${e.fullName}
- תפקידים מבוקשים: ${(e.targetRoles||[]).join(", ")}
- כישורים: ${(e.skills||[]).join(", ")}
- סיכום: ${e.summary||"לא צוין"}
- ניסיון: ${(e.experience||[]).map(r=>`${r.title} ב-${r.company}`).join(", ")}

המשרה:
- כותרת: ${t.title}
- חברה: ${t.company}
- מיקום: ${t.location}

החזר JSON בלבד: { "score": <0-100>, "recommendation": "apply"|"skip"|"maybe" }`,o=await fetch(k,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${b}`,apikey:b,"X-Plug-Key":B},body:JSON.stringify({prompt:n,returnType:"json",maxTokens:256})});if(!o.ok)throw new Error(`proxy ${o.status}`);const a=await o.json();return typeof((s=a.result)==null?void 0:s.score)=="number"?a.result.score:50}const u=t=>`<span style="width:7px;height:7px;border-radius:50%;background:${t};display:inline-block"></span>`,M=`
  display: inline-flex; align-items: center; gap: 5px;
  padding: 3px 8px; margin-top: 6px;
  background: ${U}; border: 1px solid ${i}40;
  border-radius: 20px; cursor: pointer;
  font-size: 11px; font-weight: 600; color: ${i};
  font-family: Arial, sans-serif;
`;function O(t,e){const n=e>=70?i:e>=40?"#F59E0B":"#EF4444",o=e>=70?"התאמה גבוהה":e>=40?"התאמה בינונית":"התאמה נמוכה";t.innerHTML=`${u(n)} PLUG | ${e}% התאמה`,t.title=o}function w(t,e,n){t.innerHTML=`${u(i)} PLUG | מנתח (${e}/${n})...`}function R(t){t.innerHTML=`${u("#6B7280")} PLUG | היכנס כדי לראות התאמה`}function v(t,e){t.innerHTML=`${u("#EF4444")} PLUG | שגיאה ⟳`,t.addEventListener("click",async n=>{n.stopPropagation(),t.innerHTML=`${u(i)} PLUG | מנתח...`,await j(t,e)},{once:!0})}const $=new WeakMap;async function j(t,e){try{if(y==null&&(y=await G()),!y){R(t);return}const n=await N(e,y);O(t,n)}catch{v(t,e)}}let m=0,g=0;async function x(t){m+=t.length,t.forEach(({badge:e})=>w(e,g,m));for(let e=0;e<t.length;e+=3){const n=t.slice(e,e+3);await Promise.all(n.map(async({badge:o,job:a})=>{await j(o,a),g++,t.slice(e+3).forEach(({badge:s})=>{var r;(r=s.textContent)!=null&&r.includes("מנתח")&&w(s,g,m)})}))}}function L(t,e){if(t.querySelector(".plug-wd-badge"))return;const n=document.createElement("div");n.className="plug-wd-badge",n.style.cssText=M,n.innerHTML=`${u(i)} PLUG | ממתין...`,n.title="PLUG מנתח התאמה",n.addEventListener("click",a=>{a.stopPropagation();const s=$.get(n);if(s)try{chrome.runtime.sendMessage({type:"PLUG_JOB_CLICKED",payload:{job:s}}).catch(()=>{})}catch{}}),$.set(n,e);const o=t.querySelector('[data-automation-id="jobTitle"], h3, h2');o!=null&&o.parentElement?o.parentElement.insertAdjacentElement("afterend",n):t.appendChild(n)}function I(t,e){var a;const n=document.getElementById("plug-wd-banner");n&&n.remove();const o=document.createElement("div");return o.id="plug-wd-banner",o.style.cssText=`
    position: fixed; top: 0; left: 0; right: 0; z-index: 99999;
    background: ${U}; border-bottom: 1px solid ${i}40;
    padding: 8px 16px;
    display: flex; align-items: center; justify-content: space-between;
    font-family: Arial, sans-serif; direction: rtl;
  `,o.innerHTML=`
    <span style="color:${i};font-size:13px;font-weight:700;display:flex;align-items:center;gap:8px">
      🔌 PLUG
      <span style="color:#fff;font-weight:400">
        — נמצאו <strong style="color:${i}">${t}</strong> משרות ב-${e}, מנתח התאמה...
      </span>
    </span>
    <button id="plug-wd-close" style="background:none;border:none;color:#888;font-size:16px;cursor:pointer;padding:0 4px">✕</button>
  `,document.body.prepend(o),document.body.style.paddingTop=`${o.offsetHeight+8}px`,(a=document.getElementById("plug-wd-close"))==null||a.addEventListener("click",()=>{o.remove(),document.body.style.paddingTop=""}),o}function P(t,e,n){const o=t.querySelector("span > span");o&&(e>=n?o.innerHTML=` — ניתחתי <strong style="color:${i}">${n}</strong> משרות ✓`:o.innerHTML=` — מנתח ${e}/${n} משרות...`)}const J=['[data-automation-id="jobTitle"]','li[class*="jobItem"]','li[class*="WDAY"]','[class*="job-listing"]','[data-automation-id="jobResults"] li'];function T(){for(const t of J){const e=Array.from(document.querySelectorAll(t));if(e.length>0)return e.map(n=>n.closest("li")||n)}return[]}function E(t,e){var a;const n=t.querySelector('[data-automation-id="jobTitle"], h3, h2, a'),o=((a=n==null?void 0:n.textContent)==null?void 0:a.trim().toLowerCase())||"";return e.find(s=>s.title.toLowerCase().includes(o)||o.includes(s.title.toLowerCase()))}async function C(){if(window.location.pathname.split("/").filter(Boolean)[1]==="job")return;const e=S();if(!e)return;let n=[];try{if(n=(await _(e.apiUrl,0,20)).jobPostings.map(p=>A(p,e)),n.length===0)return;chrome.runtime.sendMessage({type:"JOBS_DETECTED",payload:n}).catch(()=>{});const a=I(n.length,e.tenant);let s=0;const r=async()=>{const p=T();if(p.length===0&&s<10){s++,setTimeout(r,800);return}const c=[];p.forEach(l=>{const d=E(l,n);if(!d)return;L(l,d);const f=l.querySelector(".plug-wd-badge");f&&c.push({badge:f,job:d})}),c.length>0?(await x(c),P(a,c.length,n.length)):P(a,0,n.length)};setTimeout(r,1200);const h=new MutationObserver(()=>{const p=T(),c=[];p.forEach(l=>{if(l.querySelector(".plug-wd-badge"))return;const d=E(l,n);if(!d)return;L(l,d);const f=l.querySelector(".plug-wd-badge");f&&c.push({badge:f,job:d})}),c.length>0&&x(c)});h.observe(document.body,{childList:!0,subtree:!0}),setTimeout(()=>h.disconnect(),6e4)}catch(o){console.warn("[PLUG Workday] API fetch failed:",o)}}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>setTimeout(C,500)):setTimeout(C,500);
//# sourceMappingURL=workday.js.map
